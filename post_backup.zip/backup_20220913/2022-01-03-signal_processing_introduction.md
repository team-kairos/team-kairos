---
title: 신호 처리 서론
sidebar:
  nav: docs-ko
aside:
  toc: true
key: 20220103
tags: 신호처리
---

# 시작하면서...

살다보면 신호를 주고 받을 때가 있다. 운전을 하다가 신호등에 따라 멈추고, 다시 출발하고. 손짓으로 강아지를 부르기도 하고, 바디랭귀지로 멀리서 걸어오는 친구를 친구를 재촉하기도 한다.

그래서 생각해보면 '신호'라는 단어는 일상생활에서 광범위하게 쓰인다. 일상생활에서 쓰는 신호의 개념을 뭉뜽그려 추상화시켜보면 신호라는 것은 정보를 전달하는 것과 관련이 있는것도 같다.

시스템은 어떤가? 시스템이라는 용어는 일상 생활에서 직접적으로 사용하기에는 조금 더 formal 한 용어인 것 같다. 

사회 안전망 시스템 같은 용어에도 시스템이라는 말이 들어가 있고, 윈도우즈 맥 OS 같은 말에는 운영 체제(operating system)이라는 말로도 쓰이기도 한다.

시스템이라고 하면 느낌이 체계적이고, 어떤 개념의 총 집합체 자체를 말하는 것 같기도 하다. 


우리는 신호 처리 공부의 일련의 여정에 앞서 신호와 시스템을 간단하게나마 정의하고자 한다. 그리고 평소 생각하고 있던 '신호'와 '시스템'이라는 용어와는 사뭇 다른 의미로써의 신호/시스템을 마주하게 될 것이다.

새로운 과목을 공부할 때 첫 걸림돌은 용어이다. 하지만, 동시에 새로운 용어들을 잘 받아들인다면 해당 과목에 대한 큰 그림을 볼 수 있게 된다는 점에서 여러분에게 유용한 디딤돌이 될 수 있을 것이다.

# 신호와 시스템

## 신호란 무엇인가?

신호에 관한 여러가지 정의가 가능하겠으나, 우리가 공부하고자 하는 신호는 정보를 표현하기 위한 변화의 패턴이라고 정의하면 좋을 것 같다.

여기서 변화라는 것은 시간 상의 변화 혹은 공간 상의 변화를 모두 포함하고 있는 말이다.

시간 상 변화하는 패턴을 보이는 신호를 우리는 시계열 혹은 시간 신호라고도 부른다. 어떻게 보면 여기서 '패턴'이라는 것은 '함수'와 비슷한 의미를 갖는다.

그리고 수학적으로는 함수를 이용해 신호를 표현할 수 있다. 신호가 시간에 대한 함수라는 관점에서 <img src = "https://raw.githubusercontent.com/angeloyeo/angeloyeo.github.io/master/equations/2022-01-03-signal_processing_introduction/eq1.png">와 같이 신호를 표기할 수 있을 것이다.


예를 들어, 마이크로 수음한 음성 신호 <img src = "https://raw.githubusercontent.com/angeloyeo/angeloyeo.github.io/master/equations/2022-01-03-signal_processing_introduction/eq2.png">는 <img src = "https://raw.githubusercontent.com/angeloyeo/angeloyeo.github.io/master/equations/2022-01-03-signal_processing_introduction/eq3.png">축이 시간이고 <img src = "https://raw.githubusercontent.com/angeloyeo/angeloyeo.github.io/master/equations/2022-01-03-signal_processing_introduction/eq4.png">축이 마이크 전압인 시간에 대한 함수를 생각해볼 수 있다.


<p align = "center">
  <video width = "800" height = "auto" controls>
    <source src = "https://raw.githubusercontent.com/angeloyeo/angeloyeo.github.io/master/pics/2022-01-03-signal_processing_introduction/pic1_modified.mp4">
  </video>
  <br>
  그림 1. 징소리를 녹음한 음성 신호
</p>

---

한편, 시간 신호는 크게 연속 시간 신호와 이산(discrete) 신호의 두 종류로 나눌 수 있다[^1].

[^1]: 여기서, 엄밀하게 말하자면, 이산 시간 신호와 이산 신호는 다른 것이다. 이산 시간 신호의 <img src = "https://raw.githubusercontent.com/angeloyeo/angeloyeo.github.io/master/equations/2022-01-03-signal_processing_introduction/eq5.png">축은 시간이지만 이산 신호의 <img src = "https://raw.githubusercontent.com/angeloyeo/angeloyeo.github.io/master/equations/2022-01-03-signal_processing_introduction/eq6.png">축은 정수(integer)이다. 또, 뒤에 더 배우겠지만 이산 신호는 디지털 신호와도 다른 개념이다. 이산 신호는 무한한 정밀도를 가지지만 디지털 신호는 유한한 정밀도를 가지기 때문이다.

흔히 말하는 아날로그 신호가 바로 연속 시간 신호이다. 그리고, 수학적으로는 실함수(real function)로 연속 시간 신호를 표현할 수 있다. <img src = "https://raw.githubusercontent.com/angeloyeo/angeloyeo.github.io/master/equations/2022-01-03-signal_processing_introduction/eq7.png">축이 실수 수직선이라는 뜻이다.

예시로 들었던 마이크의 음성 신호는 연속 시간 신호일 수 있다.

이산 신호는 생소한 개념일 수도 있다. 연속 시간 신호를 샘플링한 신호가 이산 신호이다. 샘플링에 관해선 추후에 더 자세하게 배우겠지만, 연속 시간 신호가 시간에 따라 바뀌는 중 중간 중간에 값을 가져와서 그 값들을 나열하는 과정이라고 할 수 있다. 그래서 수학적인 용어를 빌리자면 이산 신호는 함수보다 수열(sequence)에 가깝다.

<p align = "center">
  <img width = "600" src = "https://raw.githubusercontent.com/angeloyeo/angeloyeo.github.io/master/pics/2022-01-03-signal_processing_introduction/pic2.png">
  <br>
  그림 2. 연속 신호를 이산 신호로 샘플링한 예시
</p>

이산 신호의 <img src = "https://raw.githubusercontent.com/angeloyeo/angeloyeo.github.io/master/equations/2022-01-03-signal_processing_introduction/eq8.png">축은 시간 <img src = "https://raw.githubusercontent.com/angeloyeo/angeloyeo.github.io/master/equations/2022-01-03-signal_processing_introduction/eq9.png"> 대신에 <img src = "https://raw.githubusercontent.com/angeloyeo/angeloyeo.github.io/master/equations/2022-01-03-signal_processing_introduction/eq10.png">이라고 적으며, <img src = "https://raw.githubusercontent.com/angeloyeo/angeloyeo.github.io/master/equations/2022-01-03-signal_processing_introduction/eq11.png">은 정수(integer)에서 따온 말이며 <img src = "https://raw.githubusercontent.com/angeloyeo/angeloyeo.github.io/master/equations/2022-01-03-signal_processing_introduction/eq12.png">와 같은 값이다. 

이산 신호를 함수로 표기할 때는 소괄호 () 대신 대괄호 []를 사용한다.

즉, 연속 시간 신호는 <img src = "https://raw.githubusercontent.com/angeloyeo/angeloyeo.github.io/master/equations/2022-01-03-signal_processing_introduction/eq13.png">와 같이 쓰고, 이산 신호는 <img src = "https://raw.githubusercontent.com/angeloyeo/angeloyeo.github.io/master/equations/2022-01-03-signal_processing_introduction/eq14.png">과 같이 쓸 수 있다.

연속 시간 신호로 모든 신호를 다 표현할 수 있을 것 같지만, 이산 신호를 굳이 배워야 하는 이유는 디지털 기기에서는 '연속'과 '무한'이라는 개념을 표현할 수 없기 때문이다. 디지털 기기에서는 연속적인 시간에 대해 표현할 수 없으므로 이산적으로 나열한 수열을 가지고 모든 신호가 표현되고 분석된다.

---

또 한편, 시간이 아닌 공간 상 변화하는 패턴을 보이는 신호도 있다. 이런 신호를 우리는 사진 혹은 그림 (영어로는 이미지)이라고 많이 부른다.

이런 신호들은 두 개의 독립 변수를 가지고 구성된 함수로 볼 수 있어서 가령 <img src = "https://raw.githubusercontent.com/angeloyeo/angeloyeo.github.io/master/equations/2022-01-03-signal_processing_introduction/eq15.png">로 표현할 수 있다.

여기서 <img src = "https://raw.githubusercontent.com/angeloyeo/angeloyeo.github.io/master/equations/2022-01-03-signal_processing_introduction/eq16.png">는 <img src = "https://raw.githubusercontent.com/angeloyeo/angeloyeo.github.io/master/equations/2022-01-03-signal_processing_introduction/eq17.png">라는 위치에서의 밝기를 의미한다. 

<p align = "center">
  <img width = "600" src = "https://raw.githubusercontent.com/angeloyeo/angeloyeo.github.io/master/pics/2022-01-03-signal_processing_introduction/pic3.png">
  <br>
  그림 3. 흑백사진 픽셀의 밝기를 256단계의 숫자로 치환해 숫자의 나열로써 이미지를 처리할 수 있다.
  <br>
  출처: <a href = "https://mozanunal.com/2019/11/img2sh/">Mozanunal.com</a>
</p>

사진 역시 마찬가지로 디지털 기기로 표현할 때는 이산화 시켜서 표현한다. 이렇게 이산화 된 사진 위의 각각의 포인트들을 픽셀이라고도 부른다.


공간 상 변화하는 패턴에 대해서 언급하긴 했지만 이후의 포스팅에서는 거의 대부분 신호라고 하면 시간 신호에 대해서 언급하게 될 것이다.

(만약 기회가 된다면 이미지 처리에 관한 공부에서 공간 신호인 사진에 대해 다루도록 하자.)

## 시스템이란 무엇인가?

글의 첫머리에서 언급했던 다양한 '시스템'들과 달리 신호 처리 과목에서 말하는 시스템은 신호를 새로운 신호 또는 다른 신호 표현으로 변화시키는 함수이다.

쉽게 말하면 입력 신호와 출력 신호 간의 변환을 담당하는 개념이라고 볼 수 있다.

보통 신호 처리 과목에서 입력 신호는 <img src = "https://raw.githubusercontent.com/angeloyeo/angeloyeo.github.io/master/equations/2022-01-03-signal_processing_introduction/eq18.png">로, 출력 신호는 <img src = "https://raw.githubusercontent.com/angeloyeo/angeloyeo.github.io/master/equations/2022-01-03-signal_processing_introduction/eq19.png">로 많이 쓴다.

변환이라는 관점에서 시스템을 <img src = "https://raw.githubusercontent.com/angeloyeo/angeloyeo.github.io/master/equations/2022-01-03-signal_processing_introduction/eq20.png">로 표현하면 입<img src = "https://raw.githubusercontent.com/angeloyeo/angeloyeo.github.io/master/equations/2022-01-03-signal_processing_introduction/eq21.png">출력의 관계는 다음과 같다.

<p align = "center"> <img src = "https://raw.githubusercontent.com/angeloyeo/angeloyeo.github.io/master/equations/2022-01-03-signal_processing_introduction/eq22.png"> </p>

예를 들어 입력을 두 배 크게 만들어서 출력시켜주는 시스템의 입출력 관계는 다음과 같다.

<p align = "center"> <img src = "https://raw.githubusercontent.com/angeloyeo/angeloyeo.github.io/master/equations/2022-01-03-signal_processing_introduction/eq23.png"> </p>

혹은 입력 신호를 미분해서 출력해주는 시스템의 입출력 관계는 다음과 같다.

<p align = "center"> <img src = "https://raw.githubusercontent.com/angeloyeo/angeloyeo.github.io/master/equations/2022-01-03-signal_processing_introduction/eq24.png"> </p>

시스템은 입력, 출력의 종류에 따라 시스템의 종류를 구별한다. 

* 입<img src = "https://raw.githubusercontent.com/angeloyeo/angeloyeo.github.io/master/equations/2022-01-03-signal_processing_introduction/eq25.png">출력이 모두 연속 시간 신호인 경우 연속 시간 시스템이라고 부른다.

* 입<img src = "https://raw.githubusercontent.com/angeloyeo/angeloyeo.github.io/master/equations/2022-01-03-signal_processing_introduction/eq26.png">출력이 모두 이산 신호인 경우는 이산 시스템이라고 부른다.

* 어떤 경우는 연속 시간 신호를 입력으로 받고 이산 신호를 출력으로 받는 시스템도 있을 수 있다. Analog-Digital Converter 시스템은 이런 시스템으로 구별할 수 있다.

* 또, 이산 신호를 입력으로 받고 연속 시간 신호를 출력으로 받는 시스템도 있을 수 있다. Digital-Analog Converter 시스템을 이런 경우로 분류할 수 있겠다.

한편, 신호를 <img src = "https://raw.githubusercontent.com/angeloyeo/angeloyeo.github.io/master/equations/2022-01-03-signal_processing_introduction/eq27.png"> 축의의 그래프로 표현했다면 시스템의 시각적 표현은 블록다이어그램을 이용해서 표현한다.

<p align = "center">
  <img src = "https://raw.githubusercontent.com/angeloyeo/angeloyeo.github.io/master/pics/2022-01-03-signal_processing_introduction/pic4.png">
  <br>
  그림 4. 시스템은 블록 다이어그램으로 표현할 수 있으며 입/출력을 연결 시켜주고 있다.
</p>

## 선형대수학과의 연결성

※ 아래의 내용을 알고 오시면 이 꼭지를 더 잘 이해할 수 있습니다.

* [벡터의 기본 연산(상수배, 덧셈)](https://angeloyeo.github.io/2020/09/07/basic_vector_operation.html)

신호와 시스템은 선형대수학에서 벡터와 행렬의 개념에 대응 시켜 볼 수 있다.

신호를 숫자의 나열로 본다는 것이 벡터의 정의에서 어긋나지 않기 때문에 디지털 기기에서는 신호를 열벡터(column vector)로 표기한다.

다시 말해, <img src = "https://raw.githubusercontent.com/angeloyeo/angeloyeo.github.io/master/equations/2022-01-03-signal_processing_introduction/eq28.png">까지 정의된 이산 신호 <img src = "https://raw.githubusercontent.com/angeloyeo/angeloyeo.github.io/master/equations/2022-01-03-signal_processing_introduction/eq29.png">를 생각해본다면 보통 이런 신호는 아래와 같은 열벡터로 표현할 수 있다[^2].

[^2]: 왜 행벡터는 안 되고 열벡터인가에 대해서는 [행벡터의 의미와 벡터의 내적](https://angeloyeo.github.io/2020/09/09/row_vector_and_inner_product.html) 편에서 행벡터와 열벡터의 역할이 어떻게 다른지를 공부해보면 납득할 수 있다.

<p align = "center"> <img src = "https://raw.githubusercontent.com/angeloyeo/angeloyeo.github.io/master/equations/2022-01-03-signal_processing_introduction/eq30.png"> </p>

그리고 행렬의 기능이 입력 벡터와 출력 벡터 간의 선형 변환이라는 관점에서 시스템을 행렬로 표현할 수도 있다.

다만, 이 경우 시스템이 유한한 길이의 이산 신호를 다루는 이산 시스템이어야 하며 동시에 선형 시스템인 경우로 한정해야 할 것이다.

그리고 선형 이산 시스템이라고 해서 모두 행렬로 바꿔서 쓸 수 있는 것은 또 아니다.

가령, 아래와 같은 시스템은 선형 시스템인데,

<p align = "center"> <img src = "https://raw.githubusercontent.com/angeloyeo/angeloyeo.github.io/master/equations/2022-01-03-signal_processing_introduction/eq31.png"> </p>

신호의 길이를 <img src = "https://raw.githubusercontent.com/angeloyeo/angeloyeo.github.io/master/equations/2022-01-03-signal_processing_introduction/eq32.png">까지로 제한하고 수식을 풀어써보면 다음과 같다.

<p align = "center"> <img src = "https://raw.githubusercontent.com/angeloyeo/angeloyeo.github.io/master/equations/2022-01-03-signal_processing_introduction/eq33.png"> </p>

그래서 이것을 행렬로 표현하자면 다음과 같을 것이다. 

<p align = "center"> <img src = "https://raw.githubusercontent.com/angeloyeo/angeloyeo.github.io/master/equations/2022-01-03-signal_processing_introduction/eq34.png"> </p>

반면, 아래와 같은 시스템은 선형 시스템이 아니므로 행렬로 표현할 수 없다.

<p align = "center"> <img src = "https://raw.githubusercontent.com/angeloyeo/angeloyeo.github.io/master/equations/2022-01-03-signal_processing_introduction/eq35.png"> </p>

만약 이산 시스템을 행렬로 표현할 수 있다면 선형대수학에서 사용하는 여러 스킬들을 적용할 수 있게 되어 여러 관점에서 시스템을 분석할 수 있게 된다.

대표적으로 이산 푸리에 변환은 [푸리에 행렬](https://angeloyeo.github.io/2020/11/08/linear_algebra_and_Fourier_transform.html)을 구성함으로써 변환 과정을 계산해낼 수 있다.