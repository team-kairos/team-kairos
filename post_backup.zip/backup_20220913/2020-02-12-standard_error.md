---
title: 표본과 표준 오차의 의미
sidebar:
  nav: docs-ko
aside:
  toc: true
key: 20200212
tags: 통계학
---

# 모집단과 표본 집단

통계학을 공부하기 시작하면 가장 먼저 듣게 되는, 마치 고교 수학에서 <집합>과 같은 위치를 차지하고 있는 개념이 바로 모집단과 표본 집단에 관한 이야기이다.

고리타분한 이야기를 좋아하지는 않지만, 검정을 위한 통계학을 이해하기 위해선 모집단과 표본 집단에 대한 이해는 매우 필수적이다.

이 내용은 중요하기 때문에 한번 더 언급하겠다. 검정을 위한 통계학을 위해선 모집단과 표본 집단이 뽑히는 과정에 대해서 면밀히 이해해야한다!

이번 article에서는 "금성에 사는 외계인 150명"이라는 가상의 모집단을 상정하고, 표본을 추출하고, 표본 통계량을 계산해보면서 모집단과 표본 집단에 대해서 이해해보고자 한다.

## 모집단(population)과 모수(parameters)

모집단은 정보를 얻고자 하는 관심 대상의 전체 집합을 일컫는다.

모집단의 개념은 실제로는 매우 추상적이면서도 정확히는 알 수 없는 값이지만 이번 article에서는 상상의 모집단을 하나 만들어보도록 하자. 

금성에 외계인이 산다고 해보자. 그리고, 그 금성에는 정확히 150명의 외계인이 살고 있고,

신의 계시에 따르면 각 외계인의 키는 다음과 같은 분포를 갖고 있다고 해보자.

<p align = "center">
    <img width = "500" src = "https://raw.githubusercontent.com/angeloyeo/angeloyeo.github.io/master/pics/2020-02-12-standard_error/pic1.png">
    <br>
    그림 1. 상상속의 모집단인 금성 외계인 150명의 키 분포
</p>

어떤 집단의 분포는 수학적으로 잘 알려진 분포를 따른다. 그 중 가장 잘 알려진 분포가 정규분포인데, 정규분포의 경우 평균값과 표준편차 값을 이용하면 형태를 파악할 수 있다.

이처럼 전체 집단의 모든 데이터를 알지 못하더라도 수학적으로 그 분포를 기술할 수 있는 특성값들을 알 수만 있다면 "얼추 비슷하게나마" 모집단의 특성을 통계적으로 확인할 수 있다.

이 특성치들을 우리는 "모수(parameter)"라고 부르는데 대표적인 모수는 다음과 같다.

* 평균
* 분산, 표준편차
* 분위수 (중위값, 1분위수, 4분위수 등...)
* 모비율

다시 말해 우리는 모집단 전체 데이터는 얻을 수 없으니, 모집단의 특성을 나타내는 모수를 파악하여 모집단의 특성을 파악하고자 한다는 것이다[^1].

[^1]: 모수 통계에 한정

문제는 한결 간단해진 것 같지만, 모수를 잘 추정하려면 어떻게 해야할까?

## 표본집단과 표본 통계량

통계학에서 표본이란 모집단의 부분집합으로 생각할 수 있다.

가령, 우리가 그림 1에서 보았던 150명의 금성인들(모집단)에서 임의로 6명을 추출한다고 생각해보자. 그 결과는 그림 2와 같을 수 있다.

<p align = "center">
    <img width = "500" src = "https://raw.githubusercontent.com/angeloyeo/angeloyeo.github.io/master/pics/2020-02-12-standard_error/pic2.png">
    <br>
    그림 2. 150명의 모집단에서 6명의 표본을 추출한 경우. (표본은 빨간색으로 표시)
</p>

표본을 추출하는 이유는 현실적인 것으로, 우리가 모집단 전체에 대해 검사하기에는 비용이 너무 많이 들기 때문이라고 볼 수 있다.

따라서 표본은 모수를 추정하기 위해 얻는다고 할 수 있다.

그런데, 표본을 추출할 때 충분히 랜덤하게 뽑는다고 가정하면, 표본은 추출할 때 마다 매번 다른 값들로 구성될 수 있지 않을까? 6명의 크기의 표본 집단을 세 번 추출해본다고 하면 그림 3의 결과와 같을 것이다.

<p align = "center">
    <img width = "800" src = "https://raw.githubusercontent.com/angeloyeo/angeloyeo.github.io/master/pics/2020-02-12-standard_error/pic3.png">
    <br>
    그림 3. 세 번 표본을 추출해보고 그 때 마다 얻게되는 표본 분포를 그린 것
</p>

그림 3에서 볼 수 있듯이 표본은 매번 추출할 때 마다 그 값이 달라지는 특성이 있다.

또한 추출된 표본들을 통계적으로 기술하기 위해서는 통계적 특징을 나타내는 수치를 만들어두면 편할 것이다. 모수와 마찬가지로 표본으로부터도 그 분포의 특성을 나타내는 표본 통계량(statistic)을 계산할 수 있다.

대표적인 표본 통계량은 다음과 같은 것들이 있다.

* 표본 평균
* 표본 표준편차
* 표본 비율

그런데, 표본이 매번 추출할 때 마다 그 값이 변하는데, 표본 통계량도 그때 그때 변하지 않을까?

맞는 말이다. 표본 통계량은 모수의 \'추정치\'로 볼 수 있고 추정된 값은 항상 오차를 수반한다.

## 추정은 오차를 수반한다: 표준 오차(☆)

표준 오차[^2]란 "표본 통계량의 표준 편차"를 의미하는 말이다.

(글을 잘 읽어봐야 한다. 말이 꼬인다.)

[^2]: 여기서, 즉 통계학에서, \'표준\'이란 말은 \'정규화 했다\'라는 의미이거나 \'평균 냈음\'이란 의미로 볼 수 있을 것 같다.

앞서 말했듯 표본이 매번 추출될 때 마다 값이 바뀌는 특성때문에 표본 통계량은 매번 그 값에 변동(혹은 오차)이 있다.

아래의 그림 4에서는 n=6인 표본을 100회 추출하면서 매번 표본 평균을 계산하여 그려가는 과정을 만들어보았다.

<p align = "center">
    <img width = "800" src = "https://raw.githubusercontent.com/angeloyeo/angeloyeo.github.io/master/pics/2020-02-12-standard_error/pic4.gif">
    <br>
    그림 4. 100 번 표본을 추출해보고 그 때 마다 얻게되는 표본 평균을 그린 것
</p>

즉, 그림 4에서 볼 수 있듯이 표본은 추출할 때 마다 그 구성값들이 모두 다르며 그때마다 표준 통계량의 값도 변한다.

### 표본 평균 평균의 표준 오차 수식적인 증명

그림 4에서 보았던 표본 평균의 표준 편차, 즉 평균의 표준 오차(Standard Error of Mean, SEM)를 구해보자.

한번에 <img src = "https://raw.githubusercontent.com/angeloyeo/angeloyeo.github.io/master/equations/2020-02-12-standard_error/eq1.png">개의 표본을 추출하는 실험을 한다고 했을 때, 표본 평균은 다음과 같이 계산할 수 있다.

<p align = "center"> <img src = "https://raw.githubusercontent.com/angeloyeo/angeloyeo.github.io/master/equations/2020-02-12-standard_error/eq2.png"> </p>

여기서 <img src = "https://raw.githubusercontent.com/angeloyeo/angeloyeo.github.io/master/equations/2020-02-12-standard_error/eq3.png">는 한번 추출한 표본 집단에서 표본값들을 의미한다.

우리가 구하려고 하는 것은 이 표본 평균(<img src = "https://raw.githubusercontent.com/angeloyeo/angeloyeo.github.io/master/equations/2020-02-12-standard_error/eq4.png">)의 표준편차이므로 우선 표본 평균의 분산값을 계산해보면 다음과 같다.

<p align = "center"> <img src = "https://raw.githubusercontent.com/angeloyeo/angeloyeo.github.io/master/equations/2020-02-12-standard_error/eq5.png"> </p>

[//]:# (식 2)

아래의 식 (3), (4)와 같은 분산 연산자의 두 가지 성질에 의하여,

<p align = "center"> <img src = "https://raw.githubusercontent.com/angeloyeo/angeloyeo.github.io/master/equations/2020-02-12-standard_error/eq6.png"> </p>

[//]:# (식 3)

<p align = "center"> <img src = "https://raw.githubusercontent.com/angeloyeo/angeloyeo.github.io/master/equations/2020-02-12-standard_error/eq7.png"> </p>

[//]:# (식 4)

식 (2)는 다음과 같이 쓸 수 있다.

<p align = "center"> <img src = "https://raw.githubusercontent.com/angeloyeo/angeloyeo.github.io/master/equations/2020-02-12-standard_error/eq8.png"> </p>

<p align = "center"> <img src = "https://raw.githubusercontent.com/angeloyeo/angeloyeo.github.io/master/equations/2020-02-12-standard_error/eq9.png"> </p>

즉, 모분산을 <img src = "https://raw.githubusercontent.com/angeloyeo/angeloyeo.github.io/master/equations/2020-02-12-standard_error/eq10.png">라고 하면, 표본 평균의 표준 편차는 

<p align = "center"> <img src = "https://raw.githubusercontent.com/angeloyeo/angeloyeo.github.io/master/equations/2020-02-12-standard_error/eq11.png"> </p>

모분산의 추정치를 <img src = "https://raw.githubusercontent.com/angeloyeo/angeloyeo.github.io/master/equations/2020-02-12-standard_error/eq12.png">라고 했을 때, 표본 평균의 표준편차는 추정치를 이용해

다음과 같이 쓸 수 있다.

<p align = "center"> <img src = "https://raw.githubusercontent.com/angeloyeo/angeloyeo.github.io/master/equations/2020-02-12-standard_error/eq13.png"> </p>

그림 4의 마지막 장면은 아래의 그림 5와 같은데 오른쪽의 표본 평균의 분포의 너비가 왼쪽의 원래의 분포에 비해 너비가 작은 것을 알 수 있다.

<p align = "center">
    <img width = "800" src = "https://raw.githubusercontent.com/angeloyeo/angeloyeo.github.io/master/pics/2020-02-12-standard_error/pic5.gif">
    <br>
    그림 5. 100 번째 표본까지의 표본 평균을 도시한 것. 
</p>

### 주의: 표준 오차와 표준 편차는 다른 개념이다

표본 평균 표준 오차(SEM)와 표준 편차를 혼용해서 사용하거나, 잘못 사용하는 경우가 있다.

특히, 논문을 보다보면 이런 실수들을 종종 찾아볼 수 있는데, 식 (8)에서 볼 수 있었듯이 SEM은 표준 편차에 비해서 항상 값이 작기 때문에 데이터를 서술할 때 더 결과가 좋아보이기 때문이다.

다시 한번 정리하자면 표준 편차는 모집단의 분포가 얼마나 퍼져있는가를 서술하는 개념이고, SEM은 평균의 추정치에 대한 불확실도를 수치화한것이다.

보통의 경우 결과를 보는 사람의 입장에서는 모집단에 관심있는 경우가 더 많으므로 데이터에 관해 기술할 때는 표준 편차(혹은 그에 준하는 추정치)를 사용해 기술해야한다.

<p align = "center">
<iframe width="560" height="315" src="https://www.youtube.com/embed/bIYBi8HjXAQ" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
</p>
# 참고문헌

* Primer of biostatistics 6th edition, Stanton A Glantz, McGraw-Hill Medical Publishing Division