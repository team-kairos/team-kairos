---
title: 정보 엔트로피(information entropy)
sidebar:
  nav: docs-ko
aside:
  toc: true
key: 20201026
tags: 통계학 머신러닝
---

# 정보란 무엇인가?

공부를 하다보면 용어에 막히는 경우가 종종 있다.

특히, 필자의 경우에는 통계학을 공부하면서 용어에서 많은 벽을 느꼈던 것 같다.

가령 [귀무가설](https://angeloyeo.github.io/2020/03/25/hypothesis.html) 같은 용어는 너무 생소하다보니 그 용어를 익히는데 애를 먹었던 좋은 예라고 할 수 있을 것 같다.

그런데, 이번 포스트에서 말하고자 하는 '정보'는 오히려 평소에 너무 자주 사용하는 용어이다보니 공부하는데 애를 먹게한 경우라고 할 수 있을 것 같다.

정보란 무엇일까? 여러가지 관점에서 '정보'를 해석할 수 있겠다.

가령, 데이터베이스의 관점에서는 정보란 데이터를 쉽게 사용할 수 있도록 가공한 것을 의미한다.

이 관점은 다분히 computer science의 관점에 따른 것인데, 데이터를 사용하는 입장에서 생각할 수 있는 추상적인 정보의 개념이라고 할 수 있다.

그러면 통계학에서 수학적으로 정보란 무엇을 뜻하는 것일까?

필자는 통계학에서 말하는 정보량을 **"깜놀도"**라고 말하고 싶다. 깜짝 놀랄만한 정도를 줄여서 말이다.

즉, 통계학에서는 놀랄만한 내용일수록 정보량이 많다고 얘기한 것이다. 

이 개념은 확률의 개념을 재해석 한 것으로도 볼 수 있는데, 다시 말해 확률이 낮은 사건일 수록 정보량은 높다. 거의 일어나지 않을 일이기 때문이다.

그러면, 일단 정보량을 수식적으로 정의하면 아마도 확률값에 반비례하는 값으로 정의하는 것이 좋을 것 같다.

즉, 어떤 사건 랜덤 변수 <img src = "https://raw.githubusercontent.com/angeloyeo/angeloyeo.github.io/master/equations/2020-10-26-information_entropy/eq1.png">에 대해 정보량(수식에서 Info로 표현)이란 개념은 다음과 같이 생각할 수도 있을 것이다.

<p align = "center"> <img src = "https://raw.githubusercontent.com/angeloyeo/angeloyeo.github.io/master/equations/2020-10-26-information_entropy/eq2.png"> <br> 식 (1) </p>

[//]:# (식 1)

## 정보량

조금 더 구체적으로, 통계학에서 정보량은 다음과 같이 정의한다.

이산 랜덤변수 <img src = "https://raw.githubusercontent.com/angeloyeo/angeloyeo.github.io/master/equations/2020-10-26-information_entropy/eq3.png">에 대해, 

<p align = "center"> <img src = "https://raw.githubusercontent.com/angeloyeo/angeloyeo.github.io/master/equations/2020-10-26-information_entropy/eq4.png"> <br> 식 (2) </p>

[//]:# (식 2)

이다.

이 때, 로그의 밑 <img src = "https://raw.githubusercontent.com/angeloyeo/angeloyeo.github.io/master/equations/2020-10-26-information_entropy/eq5.png">는 응용 분야에 따라 다르게 쓸 수 있는데, 대게 <img src = "https://raw.githubusercontent.com/angeloyeo/angeloyeo.github.io/master/equations/2020-10-26-information_entropy/eq6.png">는 <img src = "https://raw.githubusercontent.com/angeloyeo/angeloyeo.github.io/master/equations/2020-10-26-information_entropy/eq7.png"> 중 하나를 사용할 수 있다. (각각을 사용했을 때의 정보량의 단위는 bit, nit, dit이다).

일단 정보량의 정의에 음수가 붙은 것은 다음과 같이 정보량의 정의에 로그가 사용되어서이다.

<p align = "center"> <img src = "https://raw.githubusercontent.com/angeloyeo/angeloyeo.github.io/master/equations/2020-10-26-information_entropy/eq8.png"> <br> 식 (3) </p>

[//]:# (식 3)

그러면, 정보량을 정의할 때 왜 굳이 log를 붙여서 정의했을까?

정보에 대한 아래의 개념들을 만족시킬 수 있는 수식이어야 하기 때문이다.

1) 확률값(혹은 확률밀도 값)에 반비례 해야 하기 때문.

2) 두 사건의 정보량을 합치면 각 사건의 정보량을 합친 것과 같아야 함.

# 엔트로피: 평균 정보량

통계학에서 엔트로피란 평균 정보량을 얘기한다.

도입부에서와 마찬가지로 엔트로피라는 용어를 열역학에서 주로 쓰는 엔트로피와 어떻게든 연결해보려고 애쓰지는 말자.

통계학에서의 엔트로피는 열역학에서 사용하는 Gibb's 엔트로피의 수식과 닮은 점이 있고, 결국에는 연결점을 찾을 수 있다고는 하지만, '정보'에 대한 용어 소개에서 처럼 그냥 새로운 관점에서 정보 엔트로피를 생각하도록 하자.

정보 엔트로피(혹은 섀넌 엔트로피)는 평균 정보량이다.

이산 랜덤변수 <img src = "https://raw.githubusercontent.com/angeloyeo/angeloyeo.github.io/master/equations/2020-10-26-information_entropy/eq9.png">의 샘플 공간이 <img src = "https://raw.githubusercontent.com/angeloyeo/angeloyeo.github.io/master/equations/2020-10-26-information_entropy/eq10.png">이라고 할 때 정보 엔트로피는 아래와 같다.

<p align = "center"> <img src = "https://raw.githubusercontent.com/angeloyeo/angeloyeo.github.io/master/equations/2020-10-26-information_entropy/eq11.png"> <br> 식 (4) </p>

[//]:# (식 4)

여기서 <img src = "https://raw.githubusercontent.com/angeloyeo/angeloyeo.github.io/master/equations/2020-10-26-information_entropy/eq12.png">은 기댓값 연산자를 의미한다.

식 (4)가 왜 정보량의 기댓값(즉, 평균 정보량)을 의미하는지 의아하다면 다음의 예시를 다시 생각해보자.

주사위 놀이를 하는데, 1부터 6까지의 주사위 눈이 나왔을 때 각각 100원부터 600원까지를 받는다고 생각해보자.

이 때의 기댓값은 다음과 같을 것이다.

<p align = "center"> <img src = "https://raw.githubusercontent.com/angeloyeo/angeloyeo.github.io/master/equations/2020-10-26-information_entropy/eq13.png"> </p>

<p align = "center"> <img src = "https://raw.githubusercontent.com/angeloyeo/angeloyeo.github.io/master/equations/2020-10-26-information_entropy/eq14.png"> </p>

여기서 <img src = "https://raw.githubusercontent.com/angeloyeo/angeloyeo.github.io/master/equations/2020-10-26-information_entropy/eq15.png">는 <img src = "https://raw.githubusercontent.com/angeloyeo/angeloyeo.github.io/master/equations/2020-10-26-information_entropy/eq16.png">라는 사건 발생에 대해 받는 돈 (100원~600원)이라고 생각하자.

즉, 기댓값의 정의는 일어날 수 있는 사건에 대한 확률 <img src = "https://raw.githubusercontent.com/angeloyeo/angeloyeo.github.io/master/equations/2020-10-26-information_entropy/eq17.png"> 이벤트 값을 모두 합친 것이라고 할 수 있다.

따라서, 정보 엔트로피는 모든 일어날 수 있는 사건에 대한 확률 <img src = "https://raw.githubusercontent.com/angeloyeo/angeloyeo.github.io/master/equations/2020-10-26-information_entropy/eq18.png"> 정보량 값을 합친 것이므로,

<p align = "center"> <img src = "https://raw.githubusercontent.com/angeloyeo/angeloyeo.github.io/master/equations/2020-10-26-information_entropy/eq19.png"> </p>

를 계산하여 얻을 수 있는 값이다.

