---
title: 통계적 추론 - Big Picture 
sidebar:
  nav: docs-ko
aside:
  toc: true
key: 20200211
tags: 통계학
---

<p align = "center">
    <img width = "800" src = "https://raw.githubusercontent.com/angeloyeo/angeloyeo.github.io/master/pics/2020-02-11_big_picture_stats_infer/pic1.png">
    <br>
</p>